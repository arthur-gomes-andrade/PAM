package com.example.arthuretimsqlite.api;

public class AppUtil {
    public static final String TAG = "etim";

}
