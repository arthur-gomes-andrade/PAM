package com.example.atividadepamusuariosqlite.view;

import android.os.Bundle;

public class AppCampatActivity {
    protected void onCreate(Bundle savedInstanceState) {
    }
}
