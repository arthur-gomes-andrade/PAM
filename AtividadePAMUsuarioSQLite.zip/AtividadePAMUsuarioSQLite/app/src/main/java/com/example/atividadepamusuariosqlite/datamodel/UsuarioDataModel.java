    package com.example.atividadepamusuariosqlite.datamodel;

public class UsuarioDataModel{
    public static final String TABELA = "usuario";
    public static final String ID = "id";
    public static final String SENHA = "senha";
    public static final String EMAIL = "email";

    public static String queryCriarTabela = "";

    public static String criarTabela(){

        queryCriarTabela += "CREATE TABLE IF NOT EXISTS " + TABELA + " (";
        queryCriarTabela += ID + " INTEGER PRIMARY KEY AUTOINCREMENT, ";
        queryCriarTabela += SENHA + " TEXT, ";
        queryCriarTabela += EMAIL + " TEXT ";
        queryCriarTabela += ")";

        return queryCriarTabela;
    };

}