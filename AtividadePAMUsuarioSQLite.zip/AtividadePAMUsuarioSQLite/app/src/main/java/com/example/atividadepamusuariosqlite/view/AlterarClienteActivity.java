package com.example.atividadepamusuariosqlite.view;

import static android.content.Intent.getIntent;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.atividadepamusuariosqlite.R;
import com.example.atividadepamusuariosqlite.model.Cliente;

public class AlterarClienteActivity extends AppCampatActivity {
    EditText editNome, editEmail, editTelefone;
    Button btnSalvar, btnVoltar;

    Cliente cliente;
    ClienteController clienteController;

    @Override
    protected void oncreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alterar_cliente);

        editNome = findViewByID(R.id.nome);
        editEmail = FIndViewByID(R.id.email);
    }

    public class AlterarClienteActivity extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {

            editNome = findViewById(R.id.nome);
            editEmail = findViewById(R.id.email);
            editTelefone = findViewById(R.id.telefone);
            btnSalvar = findViewById(R.id.salvar);
            btnVoltar = findViewById(R.id.voltar);

            ClienteController controller = new ClienteController(this);

            // Recebe o objeto cliente da Intent
            cliente = ((Cliente) getIntent().getSerializableExtra("cliente"));

            if (cliente != null) {
                editNome.setText(cliente.getNome());
                editEmail.setText(cliente.getEmail());
                editTelefone.setText(cliente.getTelefone());
            }
            btnSalvar.setOnClickListener(v -> {

                cliente.setNome(editNome.getText().toString());
                cliente.setEmail(editEmail.getText().toString());
                cliente.setTelefone(editTelefone.getText().toString());

                if (controller.alterar(cliente)) {
                    Toast.makeText(this, "Cliente atualizado com sucesso", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "Erro ao atualizar cliente.", Toast.LENGTH_SHORT).show();
                }

            });

            btnSalvar.setOnClickListener(view -> {
            cliente setNome(editNome, getText(), toString())
            });
        }
    }
    private void setContentView(int activityAlterarCliente) {
    }
}

