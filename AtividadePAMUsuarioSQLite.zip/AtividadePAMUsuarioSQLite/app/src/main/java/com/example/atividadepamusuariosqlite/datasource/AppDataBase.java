package com.example.cauamarizatividadeiipamii.datasource;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.atividadepamusuariosqlite.datamodel.ClienteDataModel;
import com.example.cauamarizatividadeiipamii.api.AppUtil;
import com.example.cauamarizatividadeiipamii.datamodel.ClienteDataModel;

public class AppDataBase extends SQLiteOpenHelper {

    public static final String NAME = "atividade_Arthur.sqlite";
    public static int version = 2;
    SQLiteDatabase db;

    public AppDataBase(Context context){
        super(context, NAME, null, version);
        db = getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        ClienteDataModel ClienteDataModel;
        Log.i(AppUtil.TAG, "Criando a tabela " + ClienteDataModel.TABELA);
        db.execSQL(ClienteDataModel.criarTabela());
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE " + ClienteDataModel.TABELA);

    }
    public boolean insert(String, tabela, ContentValues dados){
        db= getWritableDatabase();
        boolean retorno = false;
        return db.insert(table, null, dados) > 0;
    }
}